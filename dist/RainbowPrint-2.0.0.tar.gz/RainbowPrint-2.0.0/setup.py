#!/usr/bin/env python
# coding: utf-8

# from setuptools import setup
import setuptools
setuptools.setup(
    name='RainbowPrint',
    version='2.0.0',
    author='hs',
    author_email='huangshengtx@163.com',
    description=u'在终端中输出彩色文本',
    packages=setuptools.find_packages(),
    install_requires=[],
)
